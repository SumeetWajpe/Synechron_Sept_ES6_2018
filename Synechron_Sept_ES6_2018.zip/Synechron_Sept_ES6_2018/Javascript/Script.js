var x =200,y,boolVar=true;
     console.log(typeof x);
     x = "Hello !";
     console.log(typeof x);
     console.log(x);
     console.log(y);

     function Add(x,y){
         return x + y;
     }

     console.log(Add(20,30));

     var cars = ['MERC','BMW',"AUDI"];
     var moreCars = new Array('TATA',"MAHINDRA","MARUTI");
   
   moreCars.push("FERRARI");

// ES 5
     for(var c in cars){
         console.log(cars[c]);
     }

//ES6 
for(var c of cars){
         console.log(c);
     }

     moreCars.forEach(function(car,index){
            console.log(car + " is at an index : " + index)
     });
