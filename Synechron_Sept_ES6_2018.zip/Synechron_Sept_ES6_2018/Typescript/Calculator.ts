import Pie,{Add,Product} from './Math';

console.log(Add(20,30));