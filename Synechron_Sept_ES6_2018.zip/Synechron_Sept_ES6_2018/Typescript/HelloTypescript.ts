var x = 100;   // Type Inference !
// x = "Hello !";

var str:string;// type annotation !
var i:number;
var b:boolean;
var o:any;
o = 10000;
o = "Bye !";
o = {name:'AnyType'};
o = [10,20,30,40];
console.log(o);

let aVariableWithoutAType;

function Add(x:number,y:number):number | string{
    if(x> 0){
            return x + y;
    }else{
        return 'X should be > 0 !'
    }
}

let result:number|string = Add(20,30);