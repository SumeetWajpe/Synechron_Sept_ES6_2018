function MakeAPromise(){
    // should return an object of Promise
            return new Promise(function(resolve,reject){
                var requestObj = new XMLHttpRequest();
                requestObj.open("GET",'https://jsonplaceholder.typicode.com/posts');
                requestObj.send();// makes an ajax request !
                requestObj.onreadystatechange = function(){
                    if(requestObj.readyState == 4 && requestObj.status == 200){
                            resolve(requestObj.responseText);// success
                    }else if(requestObj.readyState == 4 && requestObj.status != 200){
                            reject(requestObj.status); // error !
                    }
                }
            })

}      